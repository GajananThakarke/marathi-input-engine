# Integrating the Marathi Input Engine into your Laravel + Inertia + React app

## 0. Confirm your bundler (30 seconds)

```bash
ls vite.config.js    # if this exists, you're on Vite — proceed below
ls webpack.mix.js    # if THIS exists instead, you're on Laravel Mix — tell me, steps differ
```

Any Inertia+React starter kit from the last few years (Breeze, Jetstream, or a manual
`laravel new` since v9) uses Vite by default, so this is almost certainly you.

## 1. Copy the files

Everything under `resources/js/marathi-input/` in this package is framework-agnostic
TypeScript (the `engine/` folder) plus a React Tiptap extension (`tiptap/`) and one optional
UI component (`components/`). Drop the whole folder into your project:

```bash
cp -r resources/js/marathi-input  /path/to/your/laravel-app/resources/js/
```

**You do not need to convert your project to TypeScript.** Vite transpiles `.ts`/`.tsx`
files by their extension alone (via esbuild) — it doesn't require a `tsconfig.json` or
project-wide TS adoption. Your existing `.jsx` files and these `.ts`/`.tsx` files coexist
fine in the same Vite build, as long as `@vitejs/plugin-react` is already in your
`vite.config.js` (it is, if Tiptap/React is already working — every Inertia+React starter
kit includes it by default).

## 2. Confirm your Tiptap packages

You almost certainly already have these since your editor is working, but the extension
needs:

```bash
npm ls @tiptap/core @tiptap/pm @tiptap/react @tiptap/starter-kit
```

Works against both Tiptap v2 and v3 — `@tiptap/pm/state` (what the extension imports for
`Plugin`/`PluginKey`/`TextSelection`) has been a stable re-export of `prosemirror-state`
since v2.

## 3. Wire it into your existing editor component

Find wherever your app currently calls `useEditor({ extensions: [...] })` — that's your
existing Tiptap editor component — and add one line:

```jsx
import { MarathiInputExtension } from "./marathi-input/tiptap/MarathiInputExtension";

const editor = useEditor({
  extensions: [
    StarterKit,
    // ...your other existing extensions...
    MarathiInputExtension.configure({ enabledByDefault: true }),
  ],
  // ...your existing config...
});
```

**That's the entire required change.** Typing now transliterates live in that editor.

`MarathiEditor.example.jsx` in this package shows the same thing plus the optional pieces —
a suggestion popup and an on/off toggle button — lifted straight from the standalone demo.
Copy whichever pieces you want from it; it's a reference, not a component to import as-is.

## 4. Optional: cross-device learning (localStorage → your backend)

Out of the box, `learnWord()` corrections persist to `localStorage` — this already works
with zero backend changes, it just means learning is per-browser, not per-account (documented
in the main README's limitations section).

If you want the same user's corrections to follow them across devices, `MarathiInputController.php.example`
in this package has a ready migration + controller + routes for a `marathi_learned_words`
table. The JS side needs a small async adjustment (network calls aren't synchronous like
localStorage reads, and `engine.ts`'s bootstrap currently assumes synchronous loading) —
happy to wire that up fully if/when you want it; flagging it here as the next step rather
than guessing at your API auth setup (Sanctum vs. session vs. something else) preemptively.

## 5. Test checklist

- [ ] Type `majha nav gajanan aahe` in the editor → get `माझं नाव गजानन आहे`
- [ ] Toggle button turns the engine off → editor behaves like plain Tiptap
- [ ] Backspace mid-word undoes phonetically, not character-by-character on the Devanagari
- [ ] Existing editor features (bold, headings, your custom extensions, `onUpdate` saving to
      your Laravel backend) still work — this extension only touches ASCII-letter input, it
      doesn't intercept anything else

## Reference: what's in this package

```
resources/js/marathi-input/
  engine/                        # framework-agnostic — no Tiptap/DOM dependency
    phoneticData.ts               # स्वर/व्यंजन tables
    transliterate.ts               # tokenizer + orthography rules
    dictionary.ts                  # known-word overrides (~200 words incl. loanwords)
    inflect.ts                     # generated noun-case & verb-conjugation forms
    persistence.ts                 # localStorage-backed learning
    engine.ts                      # public API
    index.ts
  tiptap/
    MarathiInputExtension.ts       # the ProseMirror plugin — this is the integration point
    useMarathiInputState.ts        # React hook for the plugin's live state
  components/
    SuggestionPopup.tsx/.css       # optional floating candidate picker

MarathiEditor.example.jsx          # reference wiring — copy what you need
MarathiInputController.php.example # optional server-side learning persistence
```

For the full design rationale (why a dictionary layer exists, the nasal/anuswara rule, the
retroflex-capital convention, etc.), see the main project's `README.md`.

/**
 * MarathiEditor.example.jsx
 * -----------------------------------------------------------------------
 * This is a REFERENCE, not a file to import as-is — copy the parts you
 * need into your existing Tiptap editor component. It shows the minimum
 * wiring (just the extension) plus the optional UI polish (suggestion
 * popup + toggle button) from the standalone demo, adapted for an
 * Inertia/Blade + React page.
 *
 * Your existing editor component almost certainly already has a
 * `useEditor({ extensions: [...] })` call — the only REQUIRED change is
 * adding `MarathiInputExtension` to that array. Everything else here
 * (popup, toggle, guide) is optional.
 * -----------------------------------------------------------------------
 */
import { useCallback, useMemo, useRef, useState } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";

// Adjust these paths to wherever you copy the marathi-input folder under resources/js
import { MarathiInputExtension } from "./marathi-input/tiptap/MarathiInputExtension";
import { useMarathiInputState } from "./marathi-input/tiptap/useMarathiInputState";
import { SuggestionPopup } from "./marathi-input/components/SuggestionPopup";
import "./marathi-input/components/SuggestionPopup.css";

export default function MarathiEditor({ initialContent = "<p></p>", onUpdate }) {
  const wrapRef = useRef(null);
  const [enabled, setEnabled] = useState(true);

  // useMemo so the extension isn't re-created (and its plugin state reset)
  // on every render.
  const extensions = useMemo(
    () => [
      StarterKit,
      // This is the one line your existing editor needs.
      MarathiInputExtension.configure({ enabledByDefault: true }),
    ],
    []
  );

  const editor = useEditor({
    extensions,
    content: initialContent,
    editorProps: {
      attributes: { class: "marathi-editor", spellCheck: "false" },
    },
    onUpdate: onUpdate ? ({ editor }) => onUpdate(editor.getHTML()) : undefined,
  });

  const pluginState = useMarathiInputState(editor);

  const toggleEnabled = useCallback(() => {
    if (!editor) return;
    const next = !enabled;
    setEnabled(next);
    editor.commands.setMarathiInputEnabled(next);
  }, [editor, enabled]);

  // Position the suggestion popup just under the caret — optional, skip
  // this + <SuggestionPopup> below if you don't want the picker UI.
  const popupStyle = useMemo(() => {
    if (!editor || !pluginState || pluginState.wordStart === null || pluginState.activeSuggestions.length === 0) {
      return null;
    }
    try {
      const coords = editor.view.coordsAtPos(editor.state.selection.from);
      const wrapRect = wrapRef.current?.getBoundingClientRect();
      if (!wrapRect) return null;
      return { left: coords.left - wrapRect.left, top: coords.bottom - wrapRect.top + 6 };
    } catch {
      return null;
    }
  }, [editor, pluginState]);

  return (
    <div>
      <button type="button" onClick={toggleEnabled}>
        मराठी इनपुट {enabled ? "चालू" : "बंद"}
      </button>

      <div ref={wrapRef} style={{ position: "relative" }}>
        <EditorContent editor={editor} />
        {pluginState && popupStyle && (
          <SuggestionPopup
            suggestions={pluginState.activeSuggestions}
            activeIndex={pluginState.suggestionIndex}
            romanBuffer={pluginState.romanBuffer}
            style={popupStyle}
          />
        )}
      </div>
    </div>
  );
}
